<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Antique Bakery Cafe HTML Template by Tooplate</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500;600&family=Oswald:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/all.min.css"> <!-- fontawesome -->
    <!-- <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" href="css/tailwind.css">
    <link rel="stylesheet" href="css/tooplate-antique-cafe.css">
	<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
    
<!--

Tooplate 2126 Antique Cafe

https://www.tooplate.com/view/2126-antique-cafe

-->
</head>
<body>    
    <!-- Intro -->
    <div id="intro" class="parallax-window" data-parallax="scroll" data-image-src="img/bg5.jpg">
        <!-- nav id="tm-nav" class="fixed w-full" -->
            <div class="tm-container mx-auto px-2 md:py-6 text-right">
                <button class="md:hidden py-2 px-2" id="menu-toggle"><i class="fas fa-2x fa-bars tm-text-gold"></i></button>
                <ul class="mb-3 md:mb-0 text-2xl font-normal flex justify-end flex-col md:flex-row">
                    <li class="inline-block mb-4 mx-4"><a href="index.php" style="color:gold;">Home</a></li>
                    <li class="inline-block mb-4 mx-4"><a href="menu.php" style="color:gold;">Menu</a></li>
                    <li class="inline-block mb-4 mx-4"><a href="register.php" style="color:gold;">Register</a></li>
                    <li class="inline-block mb-4 mx-4"><a href="contact.php" style="color:gold;">Contact</a></li>
                </ul>
            </div>            
        </nav>  <hr>
    <div id="tooplate_main">
<?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$phone=$_POST['t3'];
$mesg=$_POST['t4'];
if(mysql_query("insert into content(name,email,phone,mesg) values('$name','$email','$phone','$mesg')"))
{$er="<font color='blue' size='+2'> Message sent successfully</font>"; }
}

?>
	
    	<h2 style="color:white;">Contact Information</h2>
            <div id="contact_form" class="col_2">
                <h3 style="color:white;">Send a message</h3>
                <form method="post" name="contact" action="#">
                    <div class="col_4">
                        <label for="phone">Name:</label>
                        <input type="text" id="t1" name="t1" class="required input_field" />
                    </div>
                    <div class="col_4 no_margin_right">
                        <label for="email">Email:</label>
                        <input type="email" id="t2" name="t2" class="validate-email required input_field" />
                    </div>
                    <div class="clear h10"></div>
                     <div class="col_4 no_margin_right">
                        <label for="phone">Phone:</label>
                        <input type="text" id="t3" name="t3" class="required input_field" />
                    </div>
                    <div class="clear"></div>
                    <label for="text">Message:</label> <textarea id="t4" name="t4" rows="0" cols="0" class="required"></textarea>
                     <input type="submit" name="sub"  id="sub" value="Send" class="submit_button" style="color:blue;"/>
                </form>
				<h2><?php echo $er;?></h2>
            </div> 
            <div class="col_2 no_margin_right">
                <div class="col_4">
                    <h3 style="color:white;">Location </h3>
                     Hledan<br />
                    NO(30) U Tun Linn Chan St,<br />
                    Kamayut Township<br /><br />
                    
                    Tel: 09254343133<br />
                    
                    
                </div>
                
			</div>
            <div class="clear"></div>
            
    </div> <!-- END of tooplate_main -->

        <div class="clear"></div>
    </div>
	
            <footer class="absolute bottom-50 left-0 w-full">
                <div class="text-blue container mx-auto tm-container p-8 text-lg flex flex-col md:flex-row justify-between">
                    <span>Our Lovely Rakkaus Cafe</span>
                    <span class="mt-5 md:mt-0">Design: <a href="https://www.tooplate.com" target="_parent">N.Harman</a></span>
                </div>                
            </footer>    

    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script>

        function checkAndShowHideMenu() {
            if(window.innerWidth < 768) {
                $('#tm-nav ul').addClass('hidden');                
            } else {
                $('#tm-nav ul').removeClass('hidden');
            }
        }

        $(function(){
            var tmNav = $('#tm-nav');
            tmNav.singlePageNav();

            checkAndShowHideMenu();
            window.addEventListener('resize', checkAndShowHideMenu);

            $('#menu-toggle').click(function(){
                $('#tm-nav ul').toggleClass('hidden');
            });

            $('#tm-nav ul li').click(function(){
                if(window.innerWidth < 768) {
                    $('#tm-nav ul').addClass('hidden');
                }                
            });

            $(document).scroll(function() {
                var distanceFromTop = $(document).scrollTop();

                if(distanceFromTop > 100) {
                    tmNav.addClass('scroll');
                } else {
                    tmNav.removeClass('scroll');
                }
            });
            
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();

                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });
        });
    </script>
</body>
</html>