<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Antique Bakery Cafe HTML Template by Tooplate</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Raleway:wght@300;400;500;600&family=Oswald:wght@600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/all.min.css"> <!-- fontawesome -->
    <!-- <link href="https://unpkg.com/tailwindcss@^2/dist/tailwind.min.css" rel="stylesheet"> -->
    <link rel="stylesheet" href="css/tailwind.css">
    <link rel="stylesheet" href="css/tooplate-antique-cafe.css">
	<link href="tooplate_style.css" rel="stylesheet" type="text/css" />
    
<!--

Tooplate 2126 Antique Cafe

https://www.tooplate.com/view/2126-antique-cafe

-->
</head>
<body>    
    <!-- Intro -->
    <div id="intro" class="parallax-window" data-parallax="scroll" data-image-src="img/bg5.jpg">
        <!-- nav id="tm-nav" class="fixed w-full" -->
            <div class="tm-container mx-auto px-2 md:py-6 text-right">
                <button class="md:hidden py-2 px-2" id="menu-toggle"><i class="fas fa-2x fa-bars tm-text-gold"></i></button>
                <ul class="mb-3 md:mb-0 text-2xl font-normal flex justify-end flex-col md:flex-row">
                    <li class="inline-block mb-4 mx-4"><a href="index.php" style="color:gold;">Home</a></li>
                    <li class="inline-block mb-4 mx-4"><a href="menu.php" style="color:gold;">Menu</a></li>
                    <li class="inline-block mb-4 mx-4"><a href="register.php" style="color:gold;">Register</a></li>
                    <li class="inline-block mb-4 mx-4"><a href="contact.php" style="color:gold;">Contact</a></li>
                </ul>
            </div>            
        </nav>  <hr>
            <div id="tooplate_main">
    	<div id="tooplate_content" class="left">
          <div id="comment_form">
            <h3 style="color:white;">Register form</h3>
            <?php
error_reporting(1);
include("connection.php");
if($_POST['sub'])
{ 
$name=$_POST['t1'];
$email=$_POST['t2'];
$password=$_POST['t3'];
$phone=$_POST['t4'];
$city=$_POST['t5'];
$town=$_POST['t6'];
if(mysql_query("insert into register(name,email,password,phone,city,town) values('$name','$email','$password','$phone','$city','$town')"))
{
//echo "<script>location.href='reg_success.php?email=$email'</script>"; 
header("location:reg_success.php?name=$name & email=$email");}
else {$error= "user already exists";}}

?>
            <form  method="post">
                <label>Name </label>
                <input type="text" name="t1" id="t1" class="input_field" />
                <label>Email</label>
                <input type="email" name="t2" id="t2" class="input_field" />
				 <label>Password</label>
                <input type="password" name="t3" id="t3" class="input_field" />
				 <label>Phone </label>
                <input type="text" name="t4" id="t4" class="input_field" />
				 <label>City </label>
                <input type="text" name="t5" id="t5" class="input_field" />
				 <label>Country </label>
                <input type="text" name="t6" id="t6" class="input_field" />
                <input type="submit" name="sub" id="sub" value="Register" class="submit_button" style="color:blue;" />
				 <input type="reset" name="Cancel" value="Cancel" class="submit_button" style="color:blue;" />
				<label><?php echo "<font color='red'>$error</font>";?></label>
            </form>
            
        
        </div>  
            
            
            
            
            
            
        </div> <!-- END of content -->
                
		
            
           
      </div>

        <div class="clear"></div>
    </div>
	
            <footer class="absolute bottom-50 left-0 w-full">
                <div class="text-blue container mx-auto tm-container p-8 text-lg flex flex-col md:flex-row justify-between">
                    <span>Our Lovely Rakkaus Cafe</span>
                    <span class="mt-5 md:mt-0">Design: <a href="https://www.tooplate.com" target="_parent">N.Harman</a></span>
                </div>                
            </footer>    

    <script src="js/jquery-3.6.0.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/jquery.singlePageNav.min.js"></script>
    <script>

        function checkAndShowHideMenu() {
            if(window.innerWidth < 768) {
                $('#tm-nav ul').addClass('hidden');                
            } else {
                $('#tm-nav ul').removeClass('hidden');
            }
        }

        $(function(){
            var tmNav = $('#tm-nav');
            tmNav.singlePageNav();

            checkAndShowHideMenu();
            window.addEventListener('resize', checkAndShowHideMenu);

            $('#menu-toggle').click(function(){
                $('#tm-nav ul').toggleClass('hidden');
            });

            $('#tm-nav ul li').click(function(){
                if(window.innerWidth < 768) {
                    $('#tm-nav ul').addClass('hidden');
                }                
            });

            $(document).scroll(function() {
                var distanceFromTop = $(document).scrollTop();

                if(distanceFromTop > 100) {
                    tmNav.addClass('scroll');
                } else {
                    tmNav.removeClass('scroll');
                }
            });
            
            document.querySelectorAll('a[href^="#"]').forEach(anchor => {
                anchor.addEventListener('click', function (e) {
                    e.preventDefault();

                    document.querySelector(this.getAttribute('href')).scrollIntoView({
                        behavior: 'smooth'
                    });
                });
            });
        });
    </script>
</body>
</html>